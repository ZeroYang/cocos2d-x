var structcocos2d_1_1_texture2_d_1_1_pixel_format_info =
[
    [ "PixelFormatInfo", "d1/d7a/structcocos2d_1_1_texture2_d_1_1_pixel_format_info.html#a5961160ae9699839265527b379067001", null ],
    [ "alpha", "d1/d7a/structcocos2d_1_1_texture2_d_1_1_pixel_format_info.html#ac21340af16e85116cc30733582577c3b", null ],
    [ "bpp", "d1/d7a/structcocos2d_1_1_texture2_d_1_1_pixel_format_info.html#a00731ab471a2b38632427d0d80a82278", null ],
    [ "compressed", "d1/d7a/structcocos2d_1_1_texture2_d_1_1_pixel_format_info.html#a8834d4dae74854bd816d9549200cf9a4", null ],
    [ "format", "d1/d7a/structcocos2d_1_1_texture2_d_1_1_pixel_format_info.html#a315212d4778d3623f1861788d027f27f", null ],
    [ "internalFormat", "d1/d7a/structcocos2d_1_1_texture2_d_1_1_pixel_format_info.html#a8aa1415b25f765edf270956973d38d54", null ],
    [ "type", "d1/d7a/structcocos2d_1_1_texture2_d_1_1_pixel_format_info.html#a579922e668b544baacb0839db8d6ae37", null ]
];