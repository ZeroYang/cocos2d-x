var structcocostudio_1_1_relative_data =
[
    [ "animations", "d1/d80/structcocostudio_1_1_relative_data.html#a67e9bd9ac8a84a41934d94808b82fcfa", null ],
    [ "armatures", "d1/d80/structcocostudio_1_1_relative_data.html#adccc8a633abe3d86c8ef150ec49d1970", null ],
    [ "plistFiles", "d1/d80/structcocostudio_1_1_relative_data.html#a8376135faaf6098cef22d205b1baa9fa", null ],
    [ "textures", "d1/d80/structcocostudio_1_1_relative_data.html#acccc3df5d884fed4a1cfe54d678b6edd", null ]
];