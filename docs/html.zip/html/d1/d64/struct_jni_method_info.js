var struct_jni_method_info =
[
    [ "classID", "d1/d64/struct_jni_method_info.html#a5b38d15de1b315d2c3cae6b5d10a13ff", null ],
    [ "env", "d1/d64/struct_jni_method_info.html#ae6f0d0cd46e56b7e299b489cb60dd27e", null ],
    [ "methodID", "d1/d64/struct_jni_method_info.html#a14f7e95c2aedc413205131d88fc01a9a", null ]
];