var classcocostudio_1_1_widget_reader =
[
    [ "WidgetReader", "d1/de9/classcocostudio_1_1_widget_reader.html#a0e300920f03aedf9cd301223a4e63a14", null ],
    [ "~WidgetReader", "d1/de9/classcocostudio_1_1_widget_reader.html#a59b6686e364b7562f5c460dadd71b226", null ],
    [ "getResourcePath", "d1/de9/classcocostudio_1_1_widget_reader.html#ab903d1e0a198ddf2594413d0c8c42b52", null ],
    [ "setAnchorPointForWidget", "d1/de9/classcocostudio_1_1_widget_reader.html#a07fe519ba95082ea222d10520e19021c", null ],
    [ "setColorPropsFromJsonDictionary", "d1/de9/classcocostudio_1_1_widget_reader.html#a15ae04eb728774ab8270f800fc32408d", null ],
    [ "setPropsFromJsonDictionary", "d1/de9/classcocostudio_1_1_widget_reader.html#a71bd325304f2c1995365ef44b9b8ca98", null ]
];