var structsp_animation_state_data =
[
    [ "defaultMix", "d1/d2d/structsp_animation_state_data.html#a93a9b64f6a8a3b435c33665f42dd28ad", null ],
    [ "entries", "d1/d2d/structsp_animation_state_data.html#a945a864be3b2d09c6bc6dc69cdb33677", null ],
    [ "skeletonData", "d1/d2d/structsp_animation_state_data.html#ab63b4feeb03a78b907e403667db4bc68", null ]
];