var classcocos2d_1_1_____double =
[
    [ "__Double", "d1/d58/classcocos2d_1_1_____double.html#a245cc1a8dc2d7f011014c5b3e0557bdc", null ],
    [ "acceptVisitor", "d1/d58/classcocos2d_1_1_____double.html#a51e1c3bbf9df8d5bb6800f817c81d70d", null ],
    [ "clone", "d1/d58/classcocos2d_1_1_____double.html#a151e190461e72c7efd80b4aea42bcf5c", null ],
    [ "getValue", "d1/d58/classcocos2d_1_1_____double.html#aae32314df0cf07ed04dcb74df3449b56", null ]
];