var classcocos2d_1_1_ease_back_in =
[
    [ "clone", "d1/d34/classcocos2d_1_1_ease_back_in.html#aa569f59c6213725c5de861c65c8f88d1", null ],
    [ "reverse", "d1/d34/classcocos2d_1_1_ease_back_in.html#ae4358774e2467d56e2d5c2802ec042bd", null ],
    [ "update", "d1/d34/classcocos2d_1_1_ease_back_in.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "__pad0__", "d1/d34/classcocos2d_1_1_ease_back_in.html#a111fce2fb3d1886083559f4b9ecba3b3", null ]
];