var _c_c_ref_ptr_8h =
[
    [ "RefPtr", "d7/d3b/classcocos2d_1_1_ref_ptr.html", "d7/d3b/classcocos2d_1_1_ref_ptr" ],
    [ "CC_REF_PTR_SAFE_RELEASE", "d1/d03/_c_c_ref_ptr_8h.html#ae8d6bc491997321af48185da88d4537d", null ],
    [ "CC_REF_PTR_SAFE_RELEASE_NULL", "d1/d03/_c_c_ref_ptr_8h.html#a9212b12a828287c745165d9f36d2df9e", null ],
    [ "CC_REF_PTR_SAFE_RETAIN", "d1/d03/_c_c_ref_ptr_8h.html#a2ece5c3643e0d8c6dc8c35b88223fd0c", null ],
    [ "dynamic_pointer_cast", "d1/d03/_c_c_ref_ptr_8h.html#ae3eb47904792894daa275f88d7a90b1e", null ],
    [ "static_pointer_cast", "d1/d03/_c_c_ref_ptr_8h.html#aa59e8c1d20441f4ae153e4b889b5f8e6", null ]
];