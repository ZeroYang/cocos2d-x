var _socket_i_o_8h =
[
    [ "SocketIO", "d3/d81/classcocos2d_1_1network_1_1_socket_i_o.html", "d3/d81/classcocos2d_1_1network_1_1_socket_i_o" ],
    [ "SIODelegate", "d7/d0a/classcocos2d_1_1network_1_1_socket_i_o_1_1_s_i_o_delegate.html", "d7/d0a/classcocos2d_1_1network_1_1_socket_i_o_1_1_s_i_o_delegate" ],
    [ "SIOClient", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client" ],
    [ "EventRegistry", "d1/dc0/_socket_i_o_8h.html#ad11dac4ceb506d70ddd160a6f22fa7e8", null ],
    [ "SIOEvent", "d1/dc0/_socket_i_o_8h.html#a015b801b0e219268ced86c241d71d038", null ]
];