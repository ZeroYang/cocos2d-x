var classcocos2d_1_1_action_manager =
[
    [ "ActionManager", "d1/d88/classcocos2d_1_1_action_manager.html#a1db007023e15c7f78905c6558466fdc7", null ],
    [ "~ActionManager", "d1/d88/classcocos2d_1_1_action_manager.html#a49758606b97f9e0a84c035130a83db1d", null ],
    [ "actionAllocWithHashElement", "d1/d88/classcocos2d_1_1_action_manager.html#a8293dcb18a5b795f1fa9bad1417c0409", null ],
    [ "addAction", "d1/d88/classcocos2d_1_1_action_manager.html#a84f6880cc8a4386e384ed62bf5cca8ab", null ],
    [ "deleteHashElement", "d1/d88/classcocos2d_1_1_action_manager.html#a3e5ddcd771035c05d4572ab1891afb8c", null ],
    [ "getActionByTag", "d1/d88/classcocos2d_1_1_action_manager.html#ae5cf1ae4e0854350c2d99bd681bb0bfb", null ],
    [ "getNumberOfRunningActionsInTarget", "d1/d88/classcocos2d_1_1_action_manager.html#a4769fa9d7e880cc9e73f28dcddd23e8b", null ],
    [ "numberOfRunningActionsInTarget", "d1/d88/classcocos2d_1_1_action_manager.html#a7aa0613bbd38757622e5a7e7c0f0b0c4", null ],
    [ "pauseAllRunningActions", "d1/d88/classcocos2d_1_1_action_manager.html#a0101dea54a7077fda7874be20e26f1ee", null ],
    [ "pauseTarget", "d1/d88/classcocos2d_1_1_action_manager.html#ab9dabba1ff6258f203c516dc3a6ec02f", null ],
    [ "removeAction", "d1/d88/classcocos2d_1_1_action_manager.html#afb8d32502ccf549ad954c8fd36b0b778", null ],
    [ "removeActionAtIndex", "d1/d88/classcocos2d_1_1_action_manager.html#a7a4e8d457b0dc90ad1edf351824aca82", null ],
    [ "removeActionByTag", "d1/d88/classcocos2d_1_1_action_manager.html#a8cd32be457834dbd0f7c9b29f402b74b", null ],
    [ "removeAllActions", "d1/d88/classcocos2d_1_1_action_manager.html#a4bd184dd9637bcdd256e589021ee576d", null ],
    [ "removeAllActionsFromTarget", "d1/d88/classcocos2d_1_1_action_manager.html#afba09555106bd84e9c7c8f42a4189bb3", null ],
    [ "resumeTarget", "d1/d88/classcocos2d_1_1_action_manager.html#a6d2260037c0d29d286fd78947c492424", null ],
    [ "resumeTargets", "d1/d88/classcocos2d_1_1_action_manager.html#a52a8856ea3a3332afe4b90cc3b400c63", null ],
    [ "update", "d1/d88/classcocos2d_1_1_action_manager.html#a2d15c24b9636f137cfe15a0db9a47c0f", null ],
    [ "_currentTarget", "d1/d88/classcocos2d_1_1_action_manager.html#a7da34a70d7a8a7e959f6526045ebff59", null ],
    [ "_currentTargetSalvaged", "d1/d88/classcocos2d_1_1_action_manager.html#ad5b5c367e1dde0b1021023087f140932", null ],
    [ "_targets", "d1/d88/classcocos2d_1_1_action_manager.html#a67389653ae11dfedb427eb4722bc1c3b", null ]
];