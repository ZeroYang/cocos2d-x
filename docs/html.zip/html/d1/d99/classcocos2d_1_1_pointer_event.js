var classcocos2d_1_1_pointer_event =
[
    [ "PointerEvent", "d1/d99/classcocos2d_1_1_pointer_event.html#ac47e0b1d4b79039ce145ca7fa27f0407", null ],
    [ "execute", "d1/d99/classcocos2d_1_1_pointer_event.html#ad5f7eb65ad7e29b7cf8fc85a5f445951", null ]
];