var classcocosbuilder_1_1_c_c_b_sequence =
[
    [ "CCBSequence", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a778066b6f56f9788a744507766f00b85", null ],
    [ "~CCBSequence", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a681d31fa2f2c94adc3259bca6bcdc70c", null ],
    [ "getCallbackChannel", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a8c502eb6418d8a594b0edb0191455b17", null ],
    [ "getChainedSequenceId", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#accc3c7829dc391d7b2bb507ef53021bc", null ],
    [ "getDuration", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a83ee44393f1e0db930be75b73ff47812", null ],
    [ "getName", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a510119ff902e4e96165a7475370be836", null ],
    [ "getSequenceId", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#ae6f04388f97921554871b6cad217808b", null ],
    [ "getSoundChannel", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#ae30a4a1bc37f5c286c67ba1bfc502e0a", null ],
    [ "setCallbackChannel", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a6b4a5c533e62b1c9f8058bc517cc8c0f", null ],
    [ "setChainedSequenceId", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a69ca7108612338dca64138cd9b728efd", null ],
    [ "setDuration", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a811fb10f2335354a36abb311f530cc3c", null ],
    [ "setName", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a242eb6273d995e696ae3c2170ebafbf5", null ],
    [ "setSequenceId", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a9fb77fe008442714a5102a427585c538", null ],
    [ "setSoundChannel", "d1/de8/classcocosbuilder_1_1_c_c_b_sequence.html#a2993554959c2c54588c886f8bca52591", null ]
];