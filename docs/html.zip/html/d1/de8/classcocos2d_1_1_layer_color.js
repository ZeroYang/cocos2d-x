var classcocos2d_1_1_layer_color =
[
    [ "~LayerColor", "d1/de8/classcocos2d_1_1_layer_color.html#a7136d079fb8223e0f2cce474b602d0cf", null ],
    [ "changeHeight", "d1/de8/classcocos2d_1_1_layer_color.html#a60b4130d8991dec4d860834913bfee93", null ],
    [ "changeWidth", "d1/de8/classcocos2d_1_1_layer_color.html#afe91e0e12a498c2680ec5b789c545a5c", null ],
    [ "changeWidthAndHeight", "d1/de8/classcocos2d_1_1_layer_color.html#a4e77da24a712426823dc29d2e66d2caa", null ],
    [ "draw", "d1/de8/classcocos2d_1_1_layer_color.html#a157adff0789268b907f88abb5f6c1000", null ],
    [ "getBlendFunc", "d1/de8/classcocos2d_1_1_layer_color.html#aad7b51987b24a49e377383a6c00ed522", null ],
    [ "getDescription", "d1/de8/classcocos2d_1_1_layer_color.html#a52b7741f1ccd38d665e153882b7dc0dd", null ],
    [ "init", "d1/de8/classcocos2d_1_1_layer_color.html#aee8048628ff2b5c026c9e15acdcaacb8", null ],
    [ "initWithColor", "d1/de8/classcocos2d_1_1_layer_color.html#a3fc0734805a1865cc6c49c2849b7492f", null ],
    [ "initWithColor", "d1/de8/classcocos2d_1_1_layer_color.html#ac94c5a84bbcdc2874a81aaf98432dcb0", null ],
    [ "onDraw", "d1/de8/classcocos2d_1_1_layer_color.html#a52c892d463e6ea3645c43b1a5fd439cc", null ],
    [ "setBlendFunc", "d1/de8/classcocos2d_1_1_layer_color.html#a06dc216f9a20530f595d680177dece65", null ],
    [ "setContentSize", "d1/de8/classcocos2d_1_1_layer_color.html#aa750885596f28a27cb177038ed43a543", null ],
    [ "updateColor", "d1/de8/classcocos2d_1_1_layer_color.html#ac83ba8274b9e282f2e54f52ddaffd56b", null ],
    [ "__pad0__", "d1/de8/classcocos2d_1_1_layer_color.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "_blendFunc", "d1/de8/classcocos2d_1_1_layer_color.html#aa6a38b8ea3b353af924472ed15b6e3aa", null ],
    [ "_customCommand", "d1/de8/classcocos2d_1_1_layer_color.html#a0eba28bd7fcaee54d8c8290f2157b17f", null ],
    [ "_noMVPVertices", "d1/de8/classcocos2d_1_1_layer_color.html#a2c1663e854dbc2bf14f4d12d13800829", null ],
    [ "_squareColors", "d1/de8/classcocos2d_1_1_layer_color.html#ae32c738b369c5cd5dbf00b7a07ccf605", null ],
    [ "_squareVertices", "d1/de8/classcocos2d_1_1_layer_color.html#a8bd9e0ba04f035237e9f44be0902d48c", null ]
];