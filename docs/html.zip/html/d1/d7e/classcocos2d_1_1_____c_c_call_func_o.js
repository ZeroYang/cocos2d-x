var classcocos2d_1_1_____c_c_call_func_o =
[
    [ "__CCCallFuncO", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#a1a4347a82f1033b002c0f2306ba572a9", null ],
    [ "~__CCCallFuncO", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#a76345a2af6bbd9e3833499c7bddbcd07", null ],
    [ "clone", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#a3ba18a989d5c98cb6489d548f28749b2", null ],
    [ "execute", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#acc52fddbab2ce2dc6ec9af13a9dd94aa", null ],
    [ "getObject", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#ac9ff86768641f364f92836120d11b04b", null ],
    [ "initWithTarget", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#adaa8815c37cdaad0991dc3e2ef8a1dd2", null ],
    [ "setObject", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#aeced8dc70a0e61fb48ad58d44fd0c552", null ],
    [ "_callFuncO", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#a89df395ac2eda7fb7d5f5f030b11ae81", null ],
    [ "_object", "d1/d7e/classcocos2d_1_1_____c_c_call_func_o.html#a98a19eb168426a26cbb1e98ae460f484", null ]
];