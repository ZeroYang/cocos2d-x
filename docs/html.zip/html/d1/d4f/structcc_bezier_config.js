var structcc_bezier_config =
[
    [ "controlPoint_1", "d1/d4f/structcc_bezier_config.html#a072f0c9b9d826117723c97d7b7e147e1", null ],
    [ "controlPoint_2", "d1/d4f/structcc_bezier_config.html#af5335b25afe67a1fbd65a9ebff312eda", null ],
    [ "endPosition", "d1/d4f/structcc_bezier_config.html#ac728ac37aa51459bc0493b4103cc9587", null ]
];