var classcocos2d_1_1_menu_item_image =
[
    [ "initWithNormalImage", "d1/d30/classcocos2d_1_1_menu_item_image.html#aef0f406831d071b4d9d19db0eec5ab92", null ],
    [ "initWithNormalImage", "d1/d30/classcocos2d_1_1_menu_item_image.html#a33b2da4387c2b09769c4231f893634d2", null ],
    [ "setDisabledSpriteFrame", "d1/d30/classcocos2d_1_1_menu_item_image.html#a70d3de46d618487900749c756b6db592", null ],
    [ "setNormalSpriteFrame", "d1/d30/classcocos2d_1_1_menu_item_image.html#abb6855b8bbf2d7742400be5ea1ff7193", null ],
    [ "setSelectedSpriteFrame", "d1/d30/classcocos2d_1_1_menu_item_image.html#ade8ccbede2909ef3bd35382d2de62e5e", null ],
    [ "__pad0__", "d1/d30/classcocos2d_1_1_menu_item_image.html#a111fce2fb3d1886083559f4b9ecba3b3", null ]
];