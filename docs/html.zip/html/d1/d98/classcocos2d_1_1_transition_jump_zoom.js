var classcocos2d_1_1_transition_jump_zoom =
[
    [ "TransitionJumpZoom", "d1/d98/classcocos2d_1_1_transition_jump_zoom.html#a0ada6b6c913e52f025f49625ffd69ac8", null ],
    [ "~TransitionJumpZoom", "d1/d98/classcocos2d_1_1_transition_jump_zoom.html#a8ccb44e2016e526df5f1120f323d259c", null ],
    [ "onEnter", "d1/d98/classcocos2d_1_1_transition_jump_zoom.html#afc7cfcc21d71b281894ff0800f4a9081", null ]
];