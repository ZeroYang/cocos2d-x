var structcocos2d_1_1_string_compare =
[
    [ "operator()", "d1/d5f/structcocos2d_1_1_string_compare.html#a3c41e010d3feac420a819a4d4e54fe89", null ]
];