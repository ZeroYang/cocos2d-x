var classcocostudio_1_1_text_field_reader =
[
    [ "TextFieldReader", "d2/d28/classcocostudio_1_1_text_field_reader.html#abb30a2e8a152fabfa93db50bd9d32d6a", null ],
    [ "~TextFieldReader", "d2/d28/classcocostudio_1_1_text_field_reader.html#a89945f54c19647e5fde533052e5fed07", null ],
    [ "setPropsFromJsonDictionary", "d2/d28/classcocostudio_1_1_text_field_reader.html#a71bd325304f2c1995365ef44b9b8ca98", null ]
];