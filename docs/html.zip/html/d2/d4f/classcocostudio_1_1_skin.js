var classcocostudio_1_1_skin =
[
    [ "Skin", "d2/d4f/classcocostudio_1_1_skin.html#ae2e060d8a70adfdfa2924139bfa7bb19", null ],
    [ "draw", "d2/d4f/classcocostudio_1_1_skin.html#a63bd941e934670d4e9a39eb59e25c8ac", null ],
    [ "getBone", "d2/d4f/classcocostudio_1_1_skin.html#ac989ffabfb5341620a9114ab46178394", null ],
    [ "getDisplayName", "d2/d4f/classcocostudio_1_1_skin.html#aa2af21177da2bd1c3e8b3ff7bb4ec6a2", null ],
    [ "getNodeToWorldTransform", "d2/d4f/classcocostudio_1_1_skin.html#afa45a0e2db6621b3659863a9e2ebded5", null ],
    [ "getNodeToWorldTransformAR", "d2/d4f/classcocostudio_1_1_skin.html#a72e89ec968bb8d2e59ccc509554aac9f", null ],
    [ "getSkinData", "d2/d4f/classcocostudio_1_1_skin.html#a5950b1d8d87bef4acbd944db6cf2b1d0", null ],
    [ "initWithFile", "d2/d4f/classcocostudio_1_1_skin.html#a96f2b5dec7d1060d03564adb19c2da7d", null ],
    [ "initWithSpriteFrameName", "d2/d4f/classcocostudio_1_1_skin.html#af5940c83bacf553a166f65ddb1e5fd4a", null ],
    [ "setBone", "d2/d4f/classcocostudio_1_1_skin.html#af1257b9122520d7f4675abf26633a0e3", null ],
    [ "setSkinData", "d2/d4f/classcocostudio_1_1_skin.html#a97f79f1fe4648ce290b1286afa2ba1e1", null ],
    [ "updateArmatureTransform", "d2/d4f/classcocostudio_1_1_skin.html#a1c99f2e0cf07e88516479d21235ce2d5", null ],
    [ "updateTransform", "d2/d4f/classcocostudio_1_1_skin.html#a6274bcceb7f61cedde5774a9600b46ea", null ],
    [ "_armature", "d2/d4f/classcocostudio_1_1_skin.html#a0eac162ba3e7b0fef4c5ce733e2a5f07", null ],
    [ "_bone", "d2/d4f/classcocostudio_1_1_skin.html#a88718a263a2a0bef198b77b321a5b90a", null ],
    [ "_displayName", "d2/d4f/classcocostudio_1_1_skin.html#a7ad773cc4d37c9cbab0462f727cae0a7", null ],
    [ "_quadCommand", "d2/d4f/classcocostudio_1_1_skin.html#ace334d843b93f3f1d2c6155e81d4c88f", null ],
    [ "_skinData", "d2/d4f/classcocostudio_1_1_skin.html#aec5ea78a297c56e351a4fd1097e6f63a", null ],
    [ "_skinTransform", "d2/d4f/classcocostudio_1_1_skin.html#af59083d63e9d29ca0db6baeade9b60ab", null ]
];