var structsp_color_timeline =
[
    [ "frames", "d2/dc7/structsp_color_timeline.html#ab96ca4f92fa2463a5f6fa31018cae73f", null ],
    [ "framesLength", "d2/dc7/structsp_color_timeline.html#ae4cbc69d36fa13e989091f123a0c8679", null ],
    [ "slotIndex", "d2/dc7/structsp_color_timeline.html#a86cf427be2b5885545e545edfeb9dd34", null ],
    [ "super", "d2/dc7/structsp_color_timeline.html#a98abd32fa35fb316f4c616148ecd9a9e", null ]
];