var classcocostudio_1_1_layout_reader =
[
    [ "LayoutReader", "d2/d8a/classcocostudio_1_1_layout_reader.html#a0ef0354b174adc87975a92cd395d64ea", null ],
    [ "~LayoutReader", "d2/d8a/classcocostudio_1_1_layout_reader.html#a908b33f4da1353bb232304cbcd78392a", null ],
    [ "setPropsFromJsonDictionary", "d2/d8a/classcocostudio_1_1_layout_reader.html#a71bd325304f2c1995365ef44b9b8ca98", null ]
];