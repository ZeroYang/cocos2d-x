var classcocos2d_1_1_transition_fade_down =
[
    [ "TransitionFadeDown", "d2/d9b/classcocos2d_1_1_transition_fade_down.html#afa9324845de30a9101ae70f8cd42833a", null ],
    [ "~TransitionFadeDown", "d2/d9b/classcocos2d_1_1_transition_fade_down.html#aa195904390be759aaad40e3660e13177", null ],
    [ "actionWithSize", "d2/d9b/classcocos2d_1_1_transition_fade_down.html#a8b6110c666983421f1e27b7ae7d99b7f", null ]
];