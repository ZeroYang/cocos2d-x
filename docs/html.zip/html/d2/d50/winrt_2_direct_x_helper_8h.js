var winrt_2_direct_x_helper_8h =
[
    [ "ThrowIfFailed", "d2/d50/winrt_2_direct_x_helper_8h.html#aec54dbc68fc3c5a426bd408e7c378aa9", null ]
];