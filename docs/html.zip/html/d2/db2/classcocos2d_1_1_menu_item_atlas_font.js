var classcocos2d_1_1_menu_item_atlas_font =
[
    [ "initWithString", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#adadac155b71d69a7fe328748ac63d6e5", null ],
    [ "__pad0__", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "charMapFile", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#a9156101c16cf6c9772d6da2ac8447843", null ],
    [ "itemHeight", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#a0fc6ba6443eab441b02d330cf6d5ac7d", null ],
    [ "itemWidth", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#a01bad64ef5413d106f88802bbef68e60", null ],
    [ "selector", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#a2f7f4c7d308d16018f054d17a1e6f4a1", null ],
    [ "startCharMap", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#ae24122e39bd0244ba48bf53cbbf508a2", null ],
    [ "target", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#a2ac34cf65792d2f9c58ca7b159ca6c98", null ]
];