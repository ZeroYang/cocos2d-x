var struct_data_info =
[
    [ "asyncStruct", "d2/d14/struct_data_info.html#a9e29529c714a73c821399dd734d492ed", null ],
    [ "baseFilePath", "d2/d14/struct_data_info.html#a2f98e3ce9378497412edd87ee46de158", null ],
    [ "cocoStudioVersion", "d2/d14/struct_data_info.html#a829820528f215796692d9a25b1aa6df7", null ],
    [ "configFileQueue", "d2/d14/struct_data_info.html#aede758719dfd7703da064535b79995bf", null ],
    [ "contentScale", "d2/d14/struct_data_info.html#aa34c340b4650e4320f33d0bebd7023d3", null ],
    [ "filename", "d2/d14/struct_data_info.html#ae80f820219e45772366a2a68de6a54c4", null ],
    [ "flashToolVersion", "d2/d14/struct_data_info.html#a9ed83b898ed5dec3d56e8825d932db03", null ]
];