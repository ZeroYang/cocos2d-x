var wp8_2_audio_8h =
[
    [ "SoundEffectData", "de/d9d/struct_sound_effect_data.html", "de/d9d/struct_sound_effect_data" ],
    [ "AudioEngineCallbacks", "da/deb/class_audio_engine_callbacks.html", "da/deb/class_audio_engine_callbacks" ],
    [ "StreamingVoiceContext", "de/d8b/struct_streaming_voice_context.html", "de/d8b/struct_streaming_voice_context" ],
    [ "Audio", "d2/d4a/class_audio.html", "d2/d4a/class_audio" ],
    [ "UNUSED_PARAM", "d2/d17/wp8_2_audio_8h.html#a6d5535aa4ba0ff64fc0e2bea1d6ea5ff", null ],
    [ "XAUDIO2_HELPER_FUNCTIONS", "d2/d17/wp8_2_audio_8h.html#a91bcb060bd6be952f1cd26029531135f", null ]
];