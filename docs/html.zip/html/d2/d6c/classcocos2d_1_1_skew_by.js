var classcocos2d_1_1_skew_by =
[
    [ "clone", "d2/d6c/classcocos2d_1_1_skew_by.html#a9ce06c9bdfd313b231e9ac724d68fccb", null ],
    [ "reverse", "d2/d6c/classcocos2d_1_1_skew_by.html#a8272a8f7c713ae35d610531dc8443019", null ],
    [ "startWithTarget", "d2/d6c/classcocos2d_1_1_skew_by.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "__pad0__", "d2/d6c/classcocos2d_1_1_skew_by.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "sx", "d2/d6c/classcocos2d_1_1_skew_by.html#a1132c57aea50274d96887a09603177e4", null ],
    [ "sy", "d2/d6c/classcocos2d_1_1_skew_by.html#a7f239d1745817c1c25eaf2ac08afdbc1", null ]
];