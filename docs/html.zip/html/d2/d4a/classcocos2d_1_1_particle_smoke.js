var classcocos2d_1_1_particle_smoke =
[
    [ "initWithTotalParticles", "d2/d4a/classcocos2d_1_1_particle_smoke.html#ac7e269df79e2dd7599ae15c4ec037942", null ],
    [ "__pad0__", "d2/d4a/classcocos2d_1_1_particle_smoke.html#a111fce2fb3d1886083559f4b9ecba3b3", null ]
];