var classcocostudio_1_1_page_view_reader =
[
    [ "PageViewReader", "d2/de2/classcocostudio_1_1_page_view_reader.html#af43c7f40eec2bdd0c8d29f2bfea04621", null ],
    [ "~PageViewReader", "d2/de2/classcocostudio_1_1_page_view_reader.html#a700a07d9152caa91452b6c3786669e96", null ],
    [ "setPropsFromJsonDictionary", "d2/de2/classcocostudio_1_1_page_view_reader.html#a71bd325304f2c1995365ef44b9b8ca98", null ]
];