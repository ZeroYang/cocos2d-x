var classcocostudio_1_1_action_rotation_frame =
[
    [ "ActionRotationFrame", "d2/d36/classcocostudio_1_1_action_rotation_frame.html#aae101e8a2ed5c65f2024956b03db7dbd", null ],
    [ "~ActionRotationFrame", "d2/d36/classcocostudio_1_1_action_rotation_frame.html#ae8beea1205f60c3ab2bed70c9ae83cc3", null ],
    [ "getAction", "d2/d36/classcocostudio_1_1_action_rotation_frame.html#a3dfe0feb4d24b57095efa2b47d94e733", null ],
    [ "getAction", "d2/d36/classcocostudio_1_1_action_rotation_frame.html#a9a6750d4ae15c7e92f60fc9a4a073912", null ],
    [ "getRotation", "d2/d36/classcocostudio_1_1_action_rotation_frame.html#aa60864de0b3c57fee5ae403229f41228", null ],
    [ "setRotation", "d2/d36/classcocostudio_1_1_action_rotation_frame.html#a10a489a162a4fb1c43c38d7f60537fe1", null ],
    [ "_rotation", "d2/d36/classcocostudio_1_1_action_rotation_frame.html#aa239104af5371676af470ba1eea1c04d", null ]
];