var classcocos2d_1_1_tint_by =
[
    [ "clone", "d2/d6b/classcocos2d_1_1_tint_by.html#a8d601718e4e9c78cb731403299ed3b3a", null ],
    [ "reverse", "d2/d6b/classcocos2d_1_1_tint_by.html#a3f3a6d3bbb4ce025dcccd9f025768516", null ],
    [ "startWithTarget", "d2/d6b/classcocos2d_1_1_tint_by.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d2/d6b/classcocos2d_1_1_tint_by.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "__pad0__", "d2/d6b/classcocos2d_1_1_tint_by.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "_deltaB", "d2/d6b/classcocos2d_1_1_tint_by.html#ab32d9f1973e762519ec0ad0067f41c6e", null ],
    [ "_deltaG", "d2/d6b/classcocos2d_1_1_tint_by.html#ae8a94621d3782ed629bea284e231bed6", null ],
    [ "_deltaR", "d2/d6b/classcocos2d_1_1_tint_by.html#a1d33ffc6e5c549eb474f3595e55513ea", null ],
    [ "_fromB", "d2/d6b/classcocos2d_1_1_tint_by.html#a65e5d9a5739f4314c74f337fa2e067be", null ],
    [ "_fromG", "d2/d6b/classcocos2d_1_1_tint_by.html#aeb9f4272bff8f04e6a46659e2e31c77a", null ],
    [ "_fromR", "d2/d6b/classcocos2d_1_1_tint_by.html#a77eff0b9e8a48997094ec4061d3b85e6", null ],
    [ "deltaBlue", "d2/d6b/classcocos2d_1_1_tint_by.html#a3fa85714d0d62cfdebf65dc69eb51124", null ],
    [ "deltaGreen", "d2/d6b/classcocos2d_1_1_tint_by.html#aab48843aa8c9db5707e377b9d3fa81ea", null ],
    [ "deltaRed", "d2/d6b/classcocos2d_1_1_tint_by.html#a7b912445fb5905e66276aa14a074533f", null ]
];