var classcocos2d_1_1_profiling_timer =
[
    [ "ProfilingTimer", "d0/dac/classcocos2d_1_1_profiling_timer.html#a06076ba0042200b4fd9762576048b1bf", null ],
    [ "~ProfilingTimer", "d0/dac/classcocos2d_1_1_profiling_timer.html#a540cc0fa60d730a44d03d16f818f8d41", null ],
    [ "getDescription", "d0/dac/classcocos2d_1_1_profiling_timer.html#a7ed943b6ae07b0f0a64b5acb31afa153", null ],
    [ "getStartTime", "d0/dac/classcocos2d_1_1_profiling_timer.html#aa5753a3deed2c464ceaba719e564c793", null ],
    [ "initWithName", "d0/dac/classcocos2d_1_1_profiling_timer.html#a45874d6993356525f10cb8fe16f34c4c", null ],
    [ "reset", "d0/dac/classcocos2d_1_1_profiling_timer.html#ad20897c5c8bd47f5d4005989bead0e55", null ],
    [ "_averageTime1", "d0/dac/classcocos2d_1_1_profiling_timer.html#ae31751aee948085ca0529680f5c28395", null ],
    [ "_averageTime2", "d0/dac/classcocos2d_1_1_profiling_timer.html#aedb56df8a2ea1b0572df485b4b4c76e4", null ],
    [ "_nameStr", "d0/dac/classcocos2d_1_1_profiling_timer.html#a2b98c54075a3b1d14e86b3a6627d2ba8", null ],
    [ "_startTime", "d0/dac/classcocos2d_1_1_profiling_timer.html#ae06e6d273caaf812b584d9fcd7d73b73", null ],
    [ "maxTime", "d0/dac/classcocos2d_1_1_profiling_timer.html#a202b790748a35745dd41986fba01033e", null ],
    [ "minTime", "d0/dac/classcocos2d_1_1_profiling_timer.html#a2789a170b49a2ce4ab81bed4aab828a0", null ],
    [ "numberOfCalls", "d0/dac/classcocos2d_1_1_profiling_timer.html#a5e9fae84f74fa598c7b73a3b97a42bd6", null ],
    [ "totalTime", "d0/dac/classcocos2d_1_1_profiling_timer.html#adfb7d439da160a39050ac6abeedea1db", null ]
];