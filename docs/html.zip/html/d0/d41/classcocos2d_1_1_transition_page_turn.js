var classcocos2d_1_1_transition_page_turn =
[
    [ "TransitionPageTurn", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a47f87c67d41ff3a5c80b1daa184e0ed8", null ],
    [ "~TransitionPageTurn", "d0/d41/classcocos2d_1_1_transition_page_turn.html#ac366a66a7b08f5f36f6572f54d3076f1", null ],
    [ "actionWithSize", "d0/d41/classcocos2d_1_1_transition_page_turn.html#addea7d2e10a39e7b452cb5fc9f4d50b3", null ],
    [ "draw", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a157adff0789268b907f88abb5f6c1000", null ],
    [ "initWithDuration", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a36996f55008e6aff99068eb9b39216ca", null ],
    [ "onDisablePolygonOffset", "d0/d41/classcocos2d_1_1_transition_page_turn.html#aede15ee834fb053a85b897e724ac5b1b", null ],
    [ "onEnablePolygonOffset", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a4bf9b83d8f36debfdf8d2a8d9e5270cf", null ],
    [ "onEnter", "d0/d41/classcocos2d_1_1_transition_page_turn.html#afc7cfcc21d71b281894ff0800f4a9081", null ],
    [ "onExit", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a9b425b901faa7243c70d90b09db89d15", null ],
    [ "sceneOrder", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a718e4f895fe74e52d743390672a6d50f", null ],
    [ "_back", "d0/d41/classcocos2d_1_1_transition_page_turn.html#ae649785a3ad5e820fbbbd71162d249ab", null ],
    [ "_disableOffsetCmd", "d0/d41/classcocos2d_1_1_transition_page_turn.html#af75112c0637a4e8a4fe4814014ff89d1", null ],
    [ "_enableOffsetCmd", "d0/d41/classcocos2d_1_1_transition_page_turn.html#ac9893f0390eeab5cd168dd458895caf2", null ],
    [ "_inSceneProxy", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a335635150f762408042be09dd2743532", null ],
    [ "_outSceneProxy", "d0/d41/classcocos2d_1_1_transition_page_turn.html#abca5ae74651d4d6d52286bc6d3d427ef", null ]
];