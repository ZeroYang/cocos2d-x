var class_lua_web_socket =
[
    [ "WebSocketScriptHandlerType", "d0/d58/class_lua_web_socket.html#a2ddd7ea40e08e6aed4ac087758984d82", [
      [ "kWebSocketScriptHandlerOpen", "d0/d58/class_lua_web_socket.html#a2ddd7ea40e08e6aed4ac087758984d82ad8e9c682a86a339cbbb0c8ae81fe4a5e", null ],
      [ "kWebSocketScriptHandlerMessage", "d0/d58/class_lua_web_socket.html#a2ddd7ea40e08e6aed4ac087758984d82ac77728cbb51614c8a0179a2b337e6f4a", null ],
      [ "kWebSocketScriptHandlerClose", "d0/d58/class_lua_web_socket.html#a2ddd7ea40e08e6aed4ac087758984d82aea879245bd0b8ab99eb53fa68fcc6fcb", null ],
      [ "kWebSocketScriptHandlerError", "d0/d58/class_lua_web_socket.html#a2ddd7ea40e08e6aed4ac087758984d82abeef3fa6175489d62032ee3f4e6c0314", null ]
    ] ],
    [ "~LuaWebSocket", "d0/d58/class_lua_web_socket.html#a085d78c002adeae23949070011de8661", null ],
    [ "onClose", "d0/d58/class_lua_web_socket.html#ab7fa3824c7b3c9a528da393fa6917ce2", null ],
    [ "onError", "d0/d58/class_lua_web_socket.html#a5e9a7933b95aa7e33e8b2b315f34ad92", null ],
    [ "onMessage", "d0/d58/class_lua_web_socket.html#a3f9a8eb18d21ddc553bda6b2c77ff9a9", null ],
    [ "onOpen", "d0/d58/class_lua_web_socket.html#a43e980d8982ee008a4cfb5656d68127b", null ]
];