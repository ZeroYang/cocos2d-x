var s3tc_8h =
[
    [ "S3TCDecodeFlag", "d0/d1e/s3tc_8h.html#af0a2a89199666df81aec7e31eae56a48", [
      [ "DXT1", "d0/d1e/s3tc_8h.html#af0a2a89199666df81aec7e31eae56a48a501bd91543c4285acd0d25a2bb2750a8", null ],
      [ "DXT3", "d0/d1e/s3tc_8h.html#af0a2a89199666df81aec7e31eae56a48a08355da49fbd688e23266ebb09afdffd", null ],
      [ "DXT5", "d0/d1e/s3tc_8h.html#af0a2a89199666df81aec7e31eae56a48aa3d1190cdb525c3e1c7c06c19005387e", null ]
    ] ],
    [ "s3tc_decode", "d0/d1e/s3tc_8h.html#a4200c8c10426bee170fec393f6c1d1b4", null ]
];