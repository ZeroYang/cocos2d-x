var classcocosbuilder_1_1_c_c_b_file =
[
    [ "CCBFile", "d0/d06/classcocosbuilder_1_1_c_c_b_file.html#a41e8bc54ea5060ff5278708dab9b7034", null ],
    [ "getCCBFileNode", "d0/d06/classcocosbuilder_1_1_c_c_b_file.html#af2e375d04e251068628589808942ef5d", null ],
    [ "setCCBFileNode", "d0/d06/classcocosbuilder_1_1_c_c_b_file.html#a8b57ca6141c5267d40375e679ca90500", null ]
];