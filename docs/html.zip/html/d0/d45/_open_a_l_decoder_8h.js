var _open_a_l_decoder_8h =
[
    [ "OpenALFile", "db/de4/struct_cocos_denshion_1_1_open_a_l_file.html", "db/de4/struct_cocos_denshion_1_1_open_a_l_file" ],
    [ "OpenALDecoder", "d8/d67/class_cocos_denshion_1_1_open_a_l_decoder.html", "d8/d67/class_cocos_denshion_1_1_open_a_l_decoder" ],
    [ "DISABLE_VORBIS", "d0/d45/_open_a_l_decoder_8h.html#acdd080a68113101070c4198a9c067bb2", null ]
];