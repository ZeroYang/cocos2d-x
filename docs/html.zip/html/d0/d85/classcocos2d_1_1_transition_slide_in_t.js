var classcocos2d_1_1_transition_slide_in_t =
[
    [ "TransitionSlideInT", "d0/d85/classcocos2d_1_1_transition_slide_in_t.html#aab3874ccca0c16a2c53c4354597c3625", null ],
    [ "~TransitionSlideInT", "d0/d85/classcocos2d_1_1_transition_slide_in_t.html#a48f6e5874c5f60098db868eec1d6e9f1", null ],
    [ "action", "d0/d85/classcocos2d_1_1_transition_slide_in_t.html#a7be0397f0a3ba4608b920bfc7b7c0f05", null ],
    [ "initScenes", "d0/d85/classcocos2d_1_1_transition_slide_in_t.html#a0c4d5b722aef81cfb729bfd8dfac5f50", null ],
    [ "sceneOrder", "d0/d85/classcocos2d_1_1_transition_slide_in_t.html#a718e4f895fe74e52d743390672a6d50f", null ]
];