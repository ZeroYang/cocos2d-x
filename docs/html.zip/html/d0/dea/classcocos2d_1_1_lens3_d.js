var classcocos2d_1_1_lens3_d =
[
    [ "clone", "d0/dea/classcocos2d_1_1_lens3_d.html#a921cc242aa31f7edf51f57e11169206b", null ],
    [ "getLensEffect", "d0/dea/classcocos2d_1_1_lens3_d.html#a9201dddcdb71d6324f3880cdbdbbe058", null ],
    [ "getPosition", "d0/dea/classcocos2d_1_1_lens3_d.html#a33dfb150cacb0ddb44a5ff242ed65575", null ],
    [ "setConcave", "d0/dea/classcocos2d_1_1_lens3_d.html#abe25ed89260f3d865ad125889499dffd", null ],
    [ "setLensEffect", "d0/dea/classcocos2d_1_1_lens3_d.html#abe95124acd2d2908b8988e399aa3c4af", null ],
    [ "setPosition", "d0/dea/classcocos2d_1_1_lens3_d.html#a5f972b6a30174047c52ab40d26e720ce", null ],
    [ "update", "d0/dea/classcocos2d_1_1_lens3_d.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "__pad0__", "d0/dea/classcocos2d_1_1_lens3_d.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "_concave", "d0/dea/classcocos2d_1_1_lens3_d.html#ad6289effdd5506fa769fec7ca2d4d9ba", null ],
    [ "_dirty", "d0/dea/classcocos2d_1_1_lens3_d.html#ad9d7d92a6dc33a9bf186020af3053844", null ],
    [ "_lensEffect", "d0/dea/classcocos2d_1_1_lens3_d.html#a9e26225a536d523b2f8da1cfb2d892d4", null ],
    [ "_position", "d0/dea/classcocos2d_1_1_lens3_d.html#a753f2273e6ae51a38804a39f37e5ac38", null ],
    [ "_radius", "d0/dea/classcocos2d_1_1_lens3_d.html#a23c2c07e43be87f216706e82059b17c4", null ],
    [ "gridSize", "d0/dea/classcocos2d_1_1_lens3_d.html#adc78cff97624774fc3b625dcd6226159", null ],
    [ "position", "d0/dea/classcocos2d_1_1_lens3_d.html#a9863cdfbef7b89c2e696b3c23e0dca2b", null ],
    [ "radius", "d0/dea/classcocos2d_1_1_lens3_d.html#a5c2dc534f48eda12bc3a13a68cc84e1b", null ]
];