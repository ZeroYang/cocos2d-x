var classcocos2d_1_1_rotate_by =
[
    [ "~RotateBy", "d0/d28/classcocos2d_1_1_rotate_by.html#af441bf13c4423a38c09be572f076da97", null ],
    [ "clone", "d0/d28/classcocos2d_1_1_rotate_by.html#af39bf2a0b300ccbdeb9c1020d5ef4d08", null ],
    [ "initWithDuration", "d0/d28/classcocos2d_1_1_rotate_by.html#ac853ed2e414c5f8b79dcece2f7b60e88", null ],
    [ "initWithDuration", "d0/d28/classcocos2d_1_1_rotate_by.html#a15f8839a2e7d6f6dc201e778e7f1a421", null ],
    [ "initWithDuration", "d0/d28/classcocos2d_1_1_rotate_by.html#aa371e869c93f90418c891efb0e7abd88", null ],
    [ "reverse", "d0/d28/classcocos2d_1_1_rotate_by.html#a6656a3d0d3eef262e5de9f6c54333a26", null ],
    [ "startWithTarget", "d0/d28/classcocos2d_1_1_rotate_by.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d0/d28/classcocos2d_1_1_rotate_by.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "__pad0__", "d0/d28/classcocos2d_1_1_rotate_by.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "_angle3D", "d0/d28/classcocos2d_1_1_rotate_by.html#acc9a5f7d269a32913ad80d903a788da7", null ],
    [ "_angleZ_X", "d0/d28/classcocos2d_1_1_rotate_by.html#a9c2b2dc8c69b640c846e09e26f9098c2", null ],
    [ "_angleZ_Y", "d0/d28/classcocos2d_1_1_rotate_by.html#adf03165ddede4b50e39e6e9c3c85556c", null ],
    [ "_is3D", "d0/d28/classcocos2d_1_1_rotate_by.html#a824334b9006a25bf84ef374c2b302940", null ],
    [ "_startAngle3D", "d0/d28/classcocos2d_1_1_rotate_by.html#ade0d711b46733ca393b60f69d83f6ed8", null ],
    [ "_startAngleZ_X", "d0/d28/classcocos2d_1_1_rotate_by.html#ade4b60d6ce19275f33aaaf829cd1a5d7", null ],
    [ "_startAngleZ_Y", "d0/d28/classcocos2d_1_1_rotate_by.html#a9df5960ef6a188ba653f20036a0b36ee", null ]
];