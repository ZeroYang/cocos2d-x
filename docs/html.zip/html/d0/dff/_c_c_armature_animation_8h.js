var _c_c_armature_animation_8h =
[
    [ "FrameEvent", "db/d5c/structcocostudio_1_1_frame_event.html", "db/d5c/structcocostudio_1_1_frame_event" ],
    [ "MovementEvent", "da/dfc/structcocostudio_1_1_movement_event.html", "da/dfc/structcocostudio_1_1_movement_event" ],
    [ "ArmatureAnimation", "de/d62/classcocostudio_1_1_armature_animation.html", "de/d62/classcocostudio_1_1_armature_animation" ],
    [ "frameEvent_selector", "d0/dff/_c_c_armature_animation_8h.html#a0aeb6bf9f364e5fed6bc1a4704ea683a", null ],
    [ "movementEvent_selector", "d0/dff/_c_c_armature_animation_8h.html#a6c5772762f52b28e2327f4072fc4659e", null ],
    [ "SEL_FrameEventCallFunc", "d0/dff/_c_c_armature_animation_8h.html#a340dca5ce507e08b24560ffd9e275910", null ],
    [ "SEL_MovementEventCallFunc", "d0/dff/_c_c_armature_animation_8h.html#a20341380afa6a2c1c49502460097c239", null ],
    [ "MovementEventType", "d0/dff/_c_c_armature_animation_8h.html#ab21a8257c7a8c9ec97c0082e1a19896b", [
      [ "START", "d0/dff/_c_c_armature_animation_8h.html#ab21a8257c7a8c9ec97c0082e1a19896ba13d000b4d7dc70d90239b7430d1eb6b2", null ],
      [ "COMPLETE", "d0/dff/_c_c_armature_animation_8h.html#ab21a8257c7a8c9ec97c0082e1a19896ba00a900c9df90c74f75004b3dc04f173d", null ],
      [ "LOOP_COMPLETE", "d0/dff/_c_c_armature_animation_8h.html#ab21a8257c7a8c9ec97c0082e1a19896baca1ee5a6a70dfbdbb1f650d6952acaf5", null ]
    ] ]
];