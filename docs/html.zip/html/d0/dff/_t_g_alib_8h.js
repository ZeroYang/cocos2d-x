var _t_g_alib_8h =
[
    [ "tImageTGA", "de/dc6/structt_image_t_g_a.html", "de/dc6/structt_image_t_g_a" ],
    [ "TGA_OK", "d0/dff/_t_g_alib_8h.html#a05589fbab0657f08285ebdfe93f5ec9eaa12b3056671d5d2d94fb7f7a2281aa7d", null ],
    [ "TGA_ERROR_FILE_OPEN", "d0/dff/_t_g_alib_8h.html#a05589fbab0657f08285ebdfe93f5ec9ead6eeba399e06c468226f468b44f85ef5", null ],
    [ "TGA_ERROR_READING_FILE", "d0/dff/_t_g_alib_8h.html#a05589fbab0657f08285ebdfe93f5ec9ea208694558561713b31e84e7b3f545a3d", null ],
    [ "TGA_ERROR_INDEXED_COLOR", "d0/dff/_t_g_alib_8h.html#a05589fbab0657f08285ebdfe93f5ec9eaea55e75ae70e5162453a52f036f42937", null ],
    [ "TGA_ERROR_MEMORY", "d0/dff/_t_g_alib_8h.html#a05589fbab0657f08285ebdfe93f5ec9ea06063b31f5406b4d8946eb3218c659ad", null ],
    [ "TGA_ERROR_COMPRESSED_FILE", "d0/dff/_t_g_alib_8h.html#a05589fbab0657f08285ebdfe93f5ec9eae08de9e0d7e7e8d934fdf7d246ebeeed", null ],
    [ "tgaDestroy", "d0/dff/_t_g_alib_8h.html#aa34c9204c817f79ede07cd50c045677c", null ],
    [ "tgaLoad", "d0/dff/_t_g_alib_8h.html#a0d8d86ec866720e150328dfc5bdbe478", null ],
    [ "tgaLoadBuffer", "d0/dff/_t_g_alib_8h.html#afa6c5526647c12155113f65980083a3b", null ],
    [ "tgaLoadHeader", "d0/dff/_t_g_alib_8h.html#a13c199f173c048b1d66ccbfc1fb0bd2c", null ],
    [ "tgaLoadImageData", "d0/dff/_t_g_alib_8h.html#ae9b878a45816613bae9607945a00c956", null ],
    [ "tgaRGBtogreyscale", "d0/dff/_t_g_alib_8h.html#a2eb0e8da39b50a855248958c4a314188", null ]
];