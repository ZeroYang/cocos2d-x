var classcocos2d_1_1_rotate_to =
[
    [ "clone", "d0/d71/classcocos2d_1_1_rotate_to.html#a410d648d78354acbad7f5691497d2344", null ],
    [ "initWithDuration", "d0/d71/classcocos2d_1_1_rotate_to.html#a37d9acf7bed722641ce3ef46769dddb4", null ],
    [ "reverse", "d0/d71/classcocos2d_1_1_rotate_to.html#a803a9958bc2810431ddd9733450ade68", null ],
    [ "startWithTarget", "d0/d71/classcocos2d_1_1_rotate_to.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d0/d71/classcocos2d_1_1_rotate_to.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "__pad0__", "d0/d71/classcocos2d_1_1_rotate_to.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "_diffAngleX", "d0/d71/classcocos2d_1_1_rotate_to.html#a4ffb347339650cca8e9e53dbba0b4d43", null ],
    [ "_diffAngleY", "d0/d71/classcocos2d_1_1_rotate_to.html#a214bd08a488bf952f072c5670974a9ca", null ],
    [ "_dstAngleX", "d0/d71/classcocos2d_1_1_rotate_to.html#a40dfeeabef086135d443f62f3d30e921", null ],
    [ "_dstAngleY", "d0/d71/classcocos2d_1_1_rotate_to.html#a1423ddfe1f50cdeb6bd9648f42c8e04f", null ],
    [ "_startAngleX", "d0/d71/classcocos2d_1_1_rotate_to.html#ab0246ab8d8e922eeedc650d7bb171286", null ],
    [ "_startAngleY", "d0/d71/classcocos2d_1_1_rotate_to.html#ab5ed03551747bb0710cb39d4d712a957", null ],
    [ "deltaAngle", "d0/d71/classcocos2d_1_1_rotate_to.html#a882b3c8e3c91f7e4b5b9c419fa8aaa82", null ]
];