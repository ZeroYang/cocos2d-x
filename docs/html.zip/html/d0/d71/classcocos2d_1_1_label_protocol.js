var classcocos2d_1_1_label_protocol =
[
    [ "~LabelProtocol", "d0/d71/classcocos2d_1_1_label_protocol.html#a374073b71e5844f6435590869e606fbe", null ],
    [ "getString", "d0/d71/classcocos2d_1_1_label_protocol.html#a3d9337abda7a53a74339662bac6f5044", null ],
    [ "setString", "d0/d71/classcocos2d_1_1_label_protocol.html#a4bf2e3f670d8420cebceb934de270513", null ]
];