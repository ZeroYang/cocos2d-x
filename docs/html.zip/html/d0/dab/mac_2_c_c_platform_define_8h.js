var mac_2_c_c_platform_define_8h =
[
    [ "CC_ASSERT", "d0/dab/mac_2_c_c_platform_define_8h.html#a9369076a1d417ecdc686cdc2dfb3295f", null ],
    [ "CC_DLL", "d0/dab/mac_2_c_c_platform_define_8h.html#af62301b55ec573e1ccc95654c6caf8fd", null ],
    [ "CC_UNUSED_PARAM", "d0/dab/mac_2_c_c_platform_define_8h.html#ae21ece0c9a97980adb466fae4c80ac3b", null ],
    [ "NULL", "d0/dab/mac_2_c_c_platform_define_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4", null ]
];