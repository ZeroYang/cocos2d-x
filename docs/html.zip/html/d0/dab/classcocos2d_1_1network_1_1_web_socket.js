var classcocos2d_1_1network_1_1_web_socket =
[
    [ "Data", "d5/dcd/structcocos2d_1_1network_1_1_web_socket_1_1_data.html", "d5/dcd/structcocos2d_1_1network_1_1_web_socket_1_1_data" ],
    [ "Delegate", "d4/d15/classcocos2d_1_1network_1_1_web_socket_1_1_delegate.html", "d4/d15/classcocos2d_1_1network_1_1_web_socket_1_1_delegate" ],
    [ "ErrorCode", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a59e56af19e754a6aa26a612ebf91d05f", [
      [ "TIME_OUT", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a59e56af19e754a6aa26a612ebf91d05faa52c72b25366cc2977dc7c505cf06a98", null ],
      [ "CONNECTION_FAILURE", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a59e56af19e754a6aa26a612ebf91d05fa9ce818a4b52e8a8c6539fe6391392369", null ],
      [ "UNKNOWN", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a59e56af19e754a6aa26a612ebf91d05fa696b031073e74bf2cb98e5ef201d4aa3", null ]
    ] ],
    [ "State", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5d74787dedbc4e11c1ab15bf487e61f8", [
      [ "CONNECTING", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5d74787dedbc4e11c1ab15bf487e61f8a9a14f95e151eec641316e7c784ce832d", null ],
      [ "OPEN", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5d74787dedbc4e11c1ab15bf487e61f8aa38bd5138bf35514df41a1795ebbf5c3", null ],
      [ "CLOSING", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5d74787dedbc4e11c1ab15bf487e61f8aa71a44c4c886bfc66b1edd511e6a677e", null ],
      [ "CLOSED", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5d74787dedbc4e11c1ab15bf487e61f8a110ccf2f5d2ff4eda1fd1a494293467d", null ]
    ] ],
    [ "WebSocket", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#aa3cb16933bc8224409ae525bbf821a79", null ],
    [ "~WebSocket", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#ad679d104906d3c4969770e5364341d01", null ],
    [ "close", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5ae591df94fc66ccb85cbb6565368bca", null ],
    [ "getReadyState", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#af87a9083db81f05363029b807fc080c8", null ],
    [ "init", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#af8bb57747592fd68700788376723da97", null ],
    [ "send", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a4d274fdc2a242187da42dcd82cd593ec", null ],
    [ "send", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5094711b8acd973c0d29ff3268a3b556", null ],
    [ "WebSocketCallbackWrapper", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a2c7ef6854d112f2cc5a708178051940e", null ],
    [ "WsThreadHelper", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a1af1dd833a9e833dbf9e9850ea609bb6", null ]
];