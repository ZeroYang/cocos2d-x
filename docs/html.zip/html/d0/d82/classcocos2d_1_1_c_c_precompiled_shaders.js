var classcocos2d_1_1_c_c_precompiled_shaders =
[
    [ "CCPrecompiledShaders", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#ab77f1f011a3beef8063e637584c4e3ed", null ],
    [ "~CCPrecompiledShaders", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a757b54acd32a6608d717e67c06097df4", null ],
    [ "addProgram", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#ab3b13b3623f81529e607ab456d8f1bb4", null ],
    [ "addShaders", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#ac5c1bfcc5b11595fa9885f0cba0d5da2", null ],
    [ "Init", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a1e3b6d38df0786ccf7f938d60e386aae", null ],
    [ "loadPrecompiledPrograms", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a0f37a87cfae0c54e2a5d141d5f96226f", null ],
    [ "loadProgram", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a77b1688f923ddb18e29f7505b0efe196", null ],
    [ "savePrecompiledPrograms", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a16f3040056a394f9ca769677f1d03f56", null ],
    [ "savePrecompiledShaders", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a748aba5a27a86883e44278949697f189", null ],
    [ "m_isDirty", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#afb7039dd5c56c4af61b88af0ad1755b5", null ],
    [ "m_precompiledPrograms", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a67fdf02ea93f3fb11523d9e49acd5236", null ],
    [ "m_programs", "d0/d82/classcocos2d_1_1_c_c_precompiled_shaders.html#a24ddf52954e4d60613f55f29d976b194", null ]
];