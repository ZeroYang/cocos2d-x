var classcocos2d_1_1_transition_slide_in_b =
[
    [ "TransitionSlideInB", "d0/d8c/classcocos2d_1_1_transition_slide_in_b.html#a78553de108e3c8c69bb3d3c25cce1d7f", null ],
    [ "~TransitionSlideInB", "d0/d8c/classcocos2d_1_1_transition_slide_in_b.html#a26df345e366d386dfeb071e9e5386be2", null ],
    [ "action", "d0/d8c/classcocos2d_1_1_transition_slide_in_b.html#a7be0397f0a3ba4608b920bfc7b7c0f05", null ],
    [ "initScenes", "d0/d8c/classcocos2d_1_1_transition_slide_in_b.html#a77fdd1caa5170d339cac0bf96dc35bee", null ],
    [ "sceneOrder", "d0/d8c/classcocos2d_1_1_transition_slide_in_b.html#a718e4f895fe74e52d743390672a6d50f", null ]
];