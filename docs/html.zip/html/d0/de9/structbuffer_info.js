var structbuffer_info =
[
    [ "bufferData", "d0/de9/structbuffer_info.html#ae1db663d23b8e34b4e1df4505a3f2c30", null ],
    [ "bufferId", "d0/de9/structbuffer_info.html#a7e31cfad7bcafea4642b81848e781318", null ],
    [ "bufferState", "d0/de9/structbuffer_info.html#afe21c11333da913a3d7b760c9168bca8", null ],
    [ "format", "d0/de9/structbuffer_info.html#a024a70d7ea52ae7af1516ffb4d2df30b", null ],
    [ "frequencyInHertz", "d0/de9/structbuffer_info.html#ae08aa67c41141edeca6763a8471fd826", null ],
    [ "sizeInBytes", "d0/de9/structbuffer_info.html#aecdb281ac9e9a54338c02229969be945", null ]
];