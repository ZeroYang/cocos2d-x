var classcocos2d_1_1_liquid =
[
    [ "clone", "d0/dfd/classcocos2d_1_1_liquid.html#aad4f072b46b1b101799122c9397f5ffc", null ],
    [ "getAmplitude", "d0/dfd/classcocos2d_1_1_liquid.html#a2eebe6231e08688ab746f9bef40757b5", null ],
    [ "getAmplitudeRate", "d0/dfd/classcocos2d_1_1_liquid.html#a85bc1a53737f46d910e729330d94337e", null ],
    [ "setAmplitude", "d0/dfd/classcocos2d_1_1_liquid.html#acd4492eedc1644fc7e48deb4a271a065", null ],
    [ "setAmplitudeRate", "d0/dfd/classcocos2d_1_1_liquid.html#a0c6226cda8f33fb69a4d3ec11c8b1774", null ],
    [ "update", "d0/dfd/classcocos2d_1_1_liquid.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "__pad0__", "d0/dfd/classcocos2d_1_1_liquid.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "_amplitude", "d0/dfd/classcocos2d_1_1_liquid.html#aeee98fea72504fe4a3934bbe5eba96db", null ],
    [ "_amplitudeRate", "d0/dfd/classcocos2d_1_1_liquid.html#ab6f824b1eebb5e8e04a3de1f0e2f2812", null ],
    [ "_waves", "d0/dfd/classcocos2d_1_1_liquid.html#a25e1364204d77e7846ecf111a1509d09", null ],
    [ "amplitude", "d0/dfd/classcocos2d_1_1_liquid.html#a81f166ee2a6b1e9f40b269020fc42cf8", null ],
    [ "gridSize", "d0/dfd/classcocos2d_1_1_liquid.html#adc78cff97624774fc3b625dcd6226159", null ],
    [ "waves", "d0/dfd/classcocos2d_1_1_liquid.html#aaca47ce82a87f33ba55d0a6099d930c2", null ]
];