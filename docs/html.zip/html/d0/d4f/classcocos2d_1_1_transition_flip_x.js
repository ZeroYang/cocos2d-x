var classcocos2d_1_1_transition_flip_x =
[
    [ "TransitionFlipX", "d0/d4f/classcocos2d_1_1_transition_flip_x.html#ad71990318da42d3556bba7dc29765bde", null ],
    [ "~TransitionFlipX", "d0/d4f/classcocos2d_1_1_transition_flip_x.html#a3925923a7ecc1280caf6687762e1b653", null ],
    [ "onEnter", "d0/d4f/classcocos2d_1_1_transition_flip_x.html#afc7cfcc21d71b281894ff0800f4a9081", null ]
];