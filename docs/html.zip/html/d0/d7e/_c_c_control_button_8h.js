var _c_c_control_button_8h =
[
    [ "ControlButtonMarginLR", "d0/d7e/_c_c_control_button_8h.html#aafaab3cb0aab66814f917154120a2293", null ],
    [ "ControlButtonMarginTB", "d0/d7e/_c_c_control_button_8h.html#abf21c784257cd3a7762cbb4193b00fad", null ]
];