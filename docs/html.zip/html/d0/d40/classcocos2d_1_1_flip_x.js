var classcocos2d_1_1_flip_x =
[
    [ "clone", "d0/d40/classcocos2d_1_1_flip_x.html#a3bb0bdae9f412406c2258f5a9fbb4bef", null ],
    [ "reverse", "d0/d40/classcocos2d_1_1_flip_x.html#aea5959e23bfef6ef834c6f9e80435bce", null ],
    [ "update", "d0/d40/classcocos2d_1_1_flip_x.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "__pad0__", "d0/d40/classcocos2d_1_1_flip_x.html#a111fce2fb3d1886083559f4b9ecba3b3", null ],
    [ "_flipX", "d0/d40/classcocos2d_1_1_flip_x.html#a47eeba35c64f80949047c619e9b8046d", null ]
];