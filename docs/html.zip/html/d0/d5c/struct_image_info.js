var struct_image_info =
[
    [ "asyncStruct", "d0/d5c/struct_image_info.html#a9e29529c714a73c821399dd734d492ed", null ],
    [ "image", "d0/d5c/struct_image_info.html#a6592824edb883c79ce94e3267887e361", null ]
];