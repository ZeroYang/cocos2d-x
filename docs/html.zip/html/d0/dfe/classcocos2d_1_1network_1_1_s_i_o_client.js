var classcocos2d_1_1network_1_1_s_i_o_client =
[
    [ "SIOClient", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#a5a85822ba356030bacd008e9d172b29f", null ],
    [ "~SIOClient", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#ac6e49271fe6d9cf605b6dcd577972949", null ],
    [ "disconnect", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#a960705de531a20389fb29928d43258c3", null ],
    [ "emit", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#ae00ac6ba0abb34b90dcf5b87233ddbe7", null ],
    [ "getDelegate", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#a1e0fc8b6a243aebabcca489fbbf35b84", null ],
    [ "getTag", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#acd0adb590bed94d7f0e542010024369d", null ],
    [ "on", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#a76be9c65fca6d5f92d7a722ab49b3356", null ],
    [ "send", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#a6a7ad506ac42a596bf87940a8b1554ed", null ],
    [ "setTag", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#a3ffb780946af4af7849d24d27d12cd0a", null ],
    [ "SIOClientImpl", "d0/dfe/classcocos2d_1_1network_1_1_s_i_o_client.html#a7d38ad7208386b9a541a435de90f5726", null ]
];