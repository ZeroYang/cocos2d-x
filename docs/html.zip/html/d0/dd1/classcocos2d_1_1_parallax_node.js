var classcocos2d_1_1_parallax_node =
[
    [ "ParallaxNode", "d0/dd1/classcocos2d_1_1_parallax_node.html#a857d2ad47f80e016baec61e3dbe3e6df", null ],
    [ "~ParallaxNode", "d0/dd1/classcocos2d_1_1_parallax_node.html#acd5b5b1614b8bfaa5c20d0cb9c074689", null ],
    [ "absolutePosition", "d0/dd1/classcocos2d_1_1_parallax_node.html#aa735d9c401f232dd8cf934813f1b6d12", null ],
    [ "addChild", "d0/dd1/classcocos2d_1_1_parallax_node.html#ac0fc88304cd79b709ae8d8710c2018c6", null ],
    [ "addChild", "d0/dd1/classcocos2d_1_1_parallax_node.html#a9bc3fb695690f6b9a722415004eefb24", null ],
    [ "getParallaxArray", "d0/dd1/classcocos2d_1_1_parallax_node.html#a00d4ca69c767bca6523b70a63e712bc5", null ],
    [ "getParallaxArray", "d0/dd1/classcocos2d_1_1_parallax_node.html#af268c8287571a5f8e0b5d1c4f2a219ca", null ],
    [ "removeAllChildrenWithCleanup", "d0/dd1/classcocos2d_1_1_parallax_node.html#aadf73dfdd41e1754ef0e2c65dff30755", null ],
    [ "removeChild", "d0/dd1/classcocos2d_1_1_parallax_node.html#a74b228862740a68c4f1e2a31bac069e4", null ],
    [ "setParallaxArray", "d0/dd1/classcocos2d_1_1_parallax_node.html#a6cf8fd4fea8c1035ccf1a36399e2430d", null ],
    [ "visit", "d0/dd1/classcocos2d_1_1_parallax_node.html#a591fbb623e834b8e9993f761371d34c1", null ],
    [ "_lastPosition", "d0/dd1/classcocos2d_1_1_parallax_node.html#ab28085eb94f6e17ad8799bd1c450ea23", null ],
    [ "_parallaxArray", "d0/dd1/classcocos2d_1_1_parallax_node.html#a9ea183f8c7be85fab0819c371d0da1cc", null ]
];