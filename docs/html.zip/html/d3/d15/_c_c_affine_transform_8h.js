var _c_c_affine_transform_8h =
[
    [ "AffineTransform", "db/dc3/structcocos2d_1_1_affine_transform.html", "db/dc3/structcocos2d_1_1_affine_transform" ],
    [ "AffineTransformMake", "d3/d15/_c_c_affine_transform_8h.html#a6f5f5e63a840aa04d1d728fd57e4bfcc", null ],
    [ "PointApplyAffineTransform", "d3/d15/_c_c_affine_transform_8h.html#acaf876df474d9bf68df41235654bec40", null ],
    [ "SizeApplyAffineTransform", "d3/d15/_c_c_affine_transform_8h.html#ab1d40a014c106f103aa32191e9541978", null ],
    [ "__CCAffineTransformMake", "d3/d15/_c_c_affine_transform_8h.html#a416dc69b46cccb16797fc6219144d644", null ],
    [ "__CCPointApplyAffineTransform", "d3/d15/_c_c_affine_transform_8h.html#a6d3196c4b4f7caec8a5bc4d5ed9a058e", null ],
    [ "__CCSizeApplyAffineTransform", "d3/d15/_c_c_affine_transform_8h.html#afd0f73c673bb3ff2cf48a82c0a88a3c5", null ],
    [ "AffineTransformConcat", "d3/d15/_c_c_affine_transform_8h.html#a90f53b3f6f7c34153a8f34683be3ab77", null ],
    [ "AffineTransformEqualToTransform", "d3/d15/_c_c_affine_transform_8h.html#af186800bcb0bc0e85406c63a2eb7b3ec", null ],
    [ "AffineTransformInvert", "d3/d15/_c_c_affine_transform_8h.html#a523c28d16232e3e980742e4a273a79f4", null ],
    [ "AffineTransformMakeIdentity", "d3/d15/_c_c_affine_transform_8h.html#a99ba5c7b81eec1a15e5484beaa529dce", null ],
    [ "AffineTransformRotate", "d3/d15/_c_c_affine_transform_8h.html#a966a8e0dcdd688ac5a6af7b13e7443fb", null ],
    [ "AffineTransformScale", "d3/d15/_c_c_affine_transform_8h.html#a1bd0a14a422984e66f99558f48b83f51", null ],
    [ "AffineTransformTranslate", "d3/d15/_c_c_affine_transform_8h.html#a9c0848acb5f4c61388ec3ec7739c6728", null ],
    [ "PointApplyTransform", "d3/d15/_c_c_affine_transform_8h.html#a11eee73e25466bae610ffcc89be4e707", null ],
    [ "RectApplyAffineTransform", "d3/d15/_c_c_affine_transform_8h.html#a479097c6958bffdd6d0b5a4509123169", null ],
    [ "RectApplyTransform", "d3/d15/_c_c_affine_transform_8h.html#aa39177a9893c0dfac082e4b29e3c5175", null ],
    [ "TransformConcat", "d3/d15/_c_c_affine_transform_8h.html#a4cabb751ad41a7a4f255664777d36dad", null ],
    [ "AffineTransformIdentity", "d3/d15/_c_c_affine_transform_8h.html#a3ea037ccb8f82eff2b09582e9f5125f4", null ]
];